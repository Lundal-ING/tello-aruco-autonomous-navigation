import cv2 as cv
import numpy as np
import numpy as np

def detect_aruco_pose(frame, camera_matrix, dist_coeffs, marker_length=0.1,
    draw=True):
    aruco_dict = cv.aruco.getPredefinedDictionary(cv.aruco.DICT_6X6_100)
    parameters = cv.aruco.DetectorParameters()
    detector = cv.aruco.ArucoDetector(aruco_dict, parameters)

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    corners, ids, _ = detector.detectMarkers(gray)

    detections = []
    if ids is not None:
        if draw:
            cv.aruco.drawDetectedMarkers(frame, corners, ids)

        obj_points = np.array([
            [-marker_length / 2, marker_length / 2, 0],
            [ marker_length / 2, marker_length / 2, 0],
            [ marker_length / 2, -marker_length / 2, 0],
            [-marker_length / 2, -marker_length / 2, 0]
        ], dtype=np.float32)

        for i, c in enumerate(corners):
            img_points = c.reshape(4, 2).astype(np.float32)
            success, rvec, tvec = cv.solvePnP(
                obj_points, img_points, camera_matrix, dist_coeffs,
                flags=cv.SOLVEPNP_IPPE_SQUARE
            )
            if not success:
                continue

            distance_cm = float(np.linalg.norm(tvec) * 100)
            detections.append({
                'id': int(ids[i][0]),
                'rvec': rvec,
                'tvec': tvec,
                'distance_cm': distance_cm
            })

            if draw:
                cv.drawFrameAxes(frame, camera_matrix, dist_coeffs, rvec,
                                 tvec, 0.05)
                cv.putText(frame, f"ID:{ids[i][0]} {distance_cm:.1f}cm",
                            tuple(img_points[0].astype(int)),
                            cv.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    return detections, frame
