import numpy as np
import matplotlib.pyplot as plt

# Draw 3D arrow axis
def draw_axes(ax, T, length=0.1, label=None):
    origin = T[:3, 3]
    x_dir = T[:3, 0] * length
    y_dir = T[:3, 1] * length
    z_dir = T[:3, 2] * length

    ax.quiver(*origin, *x_dir, color='r', linewidth=2,
              arrow_length_ratio=0.25, normalize=False)
    ax.quiver(*origin, *y_dir, color='g', linewidth=2,
              arrow_length_ratio=0.25, normalize=False)
    ax.quiver(*origin, *z_dir, color='b', linewidth=2,
        arrow_length_ratio=0.25, normalize=False)
    # Adding ID to ArUco tagg
    if label:
        ax.text(origin[0], origin[1], origin[2],
                f"ID {label}", color='k', fontsize=10, weight='bold',
                horizontalalignment='center', verticalalignment='center')


# Plott markers and camera in 3D cordinat system
def visualize_pose_relations(marker_transforms):
    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.set_title("ArUco Marker Poses (Camera at Origin)")

    # Draw the camera/world origin axes
    draw_axes(ax, np.eye(4), length=0.08, label="Camera")

    # Draw each marker's axes
    for mid, T in marker_transforms:
        draw_axes(ax, T, length=0.05, label=mid)

    # Formatting
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")
    ax.view_init(elev=30, azim=-60)
    ax.set_box_aspect([1, 1, 1])
    plt.savefig("mitt_plott.jpg")
    plt.show()
