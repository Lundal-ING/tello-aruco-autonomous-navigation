import socket, threading, time, cv2, numpy as np
from ArUco_tagg import detect_aruco_pose
from pose_tools import print_marker_poses, visualize_markers

# Drone connection
HOST, PORT = '192.168.10.3', 9000
TELLO_ADDR = ('192.168.10.1', 8889)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((HOST, PORT))

def recv():
    """Background thread to print messages from drone."""
    while True:
        try:
            data, _ = sock.recvfrom(1518)
            print(data.decode())
        except Exception:
            pass

threading.Thread(target=recv, daemon=True).start()

# Send to drone function
def send(cmd, wait=2):
    print(f"-> {cmd}")
    sock.sendto(cmd.encode(), TELLO_ADDR)
    time.sleep(wait)

# Initialize drone
send("command")
send("streamon")

# Camera setup
cap = cv2.VideoCapture("udp://0.0.0.0:11111", cv2.CAP_FFMPEG)
if not cap.isOpened():
    raise Exception("Can't open video stream")

camera_matrix = np.array([[873.27, 0, 499.24],
                            [0, 873.53, 346.61],
                            [0, 0, 1]], float)
dist_coeffs = np.array([0.121996, -1.73005, 0.005383, 0.003876, 11.8989624],
    float)
MARKER_LEN_M = 0.1

# Shared data
latest_frame = None
latest_detections = []


# Video thread
def video_loop():
    """Continuously grab frames and detect ArUco markers."""
    global latest_detections, detections
    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        # Initializing variables used in other functions
        local_detections, frame = detect_aruco_pose(frame, camera_matrix,
            dist_coeffs, MARKER_LEN_M, draw=True)
        latest_detections = local_detections
        detections = list(local_detections)

        # Displaying the video stream
        cv2.imshow("Tello ArUco Stream", frame)
        if cv2.waitKey(1) == ord('q'):
            break

# Moving to closest tag
def move_to_closest(c):
    # Moving to a set distance from the closest tag
    set_distance = 50
    if c['distance_cm'] < set_distance:
        move_bw = set_distance - c['distance_cm']
        send(f"back {round(move_bw)}")
    else:
        move_fw = c['distance_cm'] - set_distance
        send(f"forward {round(move_fw)}")

# Rotational search for tags
def search_for_tags(timeout_per_step=0.5):
    rotation_steps = 20
    total_steps = int(360 // rotation_steps)
    global detections
    tags_found = []
    all_ids = []

    # rotate one step (cw) and allow video thread to update detections
    for i in range(1,total_steps+1):
        send(f'cw {rotation_steps}')

        end_time = time.time() + timeout_per_step
        while time.time() < end_time:
            if detections:
                for d in detections:
                    dist = d.get('distance_cm')
                    if dist is None:
                        continue
                    elif int(d['id']) in all_ids:
                        continue

                    # Saving new tags detected
                    tags_found.append({
                        'id': int(d['id']),
                        'distance_cm': float(dist),
                        'angle': int(i * rotation_steps)})
                    all_ids.append(int(d['id']))
                print(f"Search detected ids={[k['id'] for k in detections]} at "
                      f"{int(i*rotation_steps)}, {[d['distance_cm'] for d in detections]} cm away°")
                break
            else:
                print('No tags detected yet')
            time.sleep(0.1)
    send('cw 15', 1)

    if not tags_found:
        print("No tags detected during search")
        return None

    # find the closest saved tag
    closest = min(tags_found, key=lambda x: x['distance_cm'])
    print(f"Closest found: id={closest['id']} "
          f"dist={closest['distance_cm']:.1f}cm angle={closest['angle']}°")
    # rotate back to face the closest tag
    angle = closest['angle'] % 360
    time.sleep(2)
    if angle == 0:
        pass
    elif angle <= 180:
        send(f"cw {int(angle) + rotation_steps}", wait=2)
    else:
        send(f"ccw {int(360 - angle - rotation_steps)}", wait=2)

    return closest


# Manual command loop
def cmd_loop():
    # Aquiering using inputs and sending to drone
    global latest_detections
    while True:
        try:
            msg = input("Command: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            msg = "end"

        if msg == "end":
            send("streamoff", 1)
            running = False
            break

        elif msg == "search":
            closest_tag = search_for_tags()
            print(f"Closest alt mulig rart {closest_tag}")

        elif msg == "pose":
            print_marker_poses(latest_detections)

        elif msg == "plott":
            visualize_markers(latest_detections)

        elif msg == "start":
            send("takeoff")
            time.sleep(5)
            plot_variable = latest_detections
            time.sleep(2)

            closest_tag = search_for_tags()
            print(f"Closest tag: {closest_tag}")
            time.sleep(5)
            move_to_closest(closest_tag)
            time.sleep(2)
            print_marker_poses(latest_detections)
            time.sleep(2)
            send("land")
            time.sleep(3)
            visualize_markers(plot_variable)
            time.sleep(3)
        elif msg:
            send(msg)

threading.Thread(target=video_loop, daemon=True).start()

cmd_loop()

# Cleanup
cap.release()
cv2.destroyAllWindows()
sock.close()
import cv2 as cv
