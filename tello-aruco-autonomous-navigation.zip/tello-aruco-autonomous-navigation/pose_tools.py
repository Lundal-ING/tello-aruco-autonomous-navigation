import numpy as np
import cv2
from Visualize import visualize_pose_relations


# Print pose for each detected ArUco marker relative to camera
def print_marker_poses(detections):
    if len(detections) == 0:
        print("No ArUco taggs detected.")
        return

    print("\n---- Marker Poses (relative to camera) ----")
    for det in detections:
        rvec = np.degrees(det["rvec"].flatten())
        tvec = det["tvec"].flatten() * 100
        print(f"ID {det['id']:>3} | Distance: {det['distance_cm']:.1f} cm")
        print(f" Translation (cm): x={tvec[0]:.2f}, y={tvec[1]:.2f}, "
              f"z={tvec[2]:.2f}")
        print(f" Rotation vector : [{rvec[0]:.3f}, {rvec[1]:.3f}, "
              f"{rvec[2]:.3f}]")
        print()


# Convert detected ArUco poses to world coordinates and plot them in 3D. The
# camera is at (0,0,0)
def visualize_markers(detections):
    if len(detections) == 0:
        print("No ArUco taggs detected.")
        return

    R_cv2mpl = np.array([
        [1, 0, 0], # X stays the same
        [0, 0, 1], # Y (down) →forward
        [0, -1, 0] # Z (forward) →up
    ])
    marker_transforms = []

    for det in detections:
        R_cv, _ = cv2.Rodrigues(det['rvec'])

        T_cv = np.eye(4)
        T_cv[:3, :3] = R_cv
        T_cv[:3, 3] = det['tvec'].flatten()

        T_mpl = np.eye(4)
        T_mpl[:3, :3] = R_cv2mpl @ T_cv[:3, :3]
        T_mpl[:3, 3] = R_cv2mpl @ T_cv[:3, 3]
        marker_transforms.append((det['id'], T_mpl))

    visualize_pose_relations(marker_transforms)
