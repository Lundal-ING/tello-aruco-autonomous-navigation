import cv2 as cv
import glob
import yaml
import socket, threading, time, cv2


HOST, PORT = '192.168.10.2', 9000
TELLO_ADDR = ('192.168.10.1', 8889)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((HOST, PORT))

# Receiver thread
def recv():
    while True:
        try:
            data, _ = sock.recvfrom(1518)
            print(data.decode())
        except Exception:
            pass
threading.Thread(target=recv, daemon=True).start()

# Start Tello
def send(cmd, wait=2):
    print(f"-> {cmd}")
    sock.sendto(cmd.encode(), TELLO_ADDR)
    time.sleep(wait)

send("command")
send("streamon")

# Video setup
cap = cv2.VideoCapture("udp://0.0.0.0:11111", cv2.CAP_FFMPEG)
if not cap.isOpened():
    raise Exception("Can't open video stream")


# Termination criteria for corner sub-pix
criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)

chessboard_size = (10, 7)
objp = np.zeros((chessboard_size[0] * chessboard_size[1], 3), np.float32)
objp[:, :2] = np.mgrid[0:chessboard_size[0],
    0:chessboard_size[1]].T.reshape(-1, 2)
# Arrays to store object points and image points from all the images
objpoints = [] # 3D points in real-world space
imgpoints = [] # 2D points in image plane

# Get the list of images

images = []
print("Press SPACE to capture images, ESC to finish.")

while True:
    ret, frame = cap.read()
    if not ret:
        break
    cv.imshow('Camera', frame)
    key = cv.waitKey(1)
    if key == 32: # SPACE
        fname = f"frame_{len(images)}.jpg"
        cv.imwrite(fname, frame)
        images.append(fname)
        print(f"Captured {fname}")
    elif key == 27: # ESC
        break

cap.release()
cv.destroyAllWindows()

# Loop over the image files and find chessboard corners
for fname in images:
    img = cv.imread(fname)
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

    # Find the chessboard corners
    ret, corners = cv.findChessboardCorners(gray, chessboard_size, None)

    # If found, add object points and image points (after refining them)
    if ret:
        objpoints.append(objp)
        corners2 = cv.cornerSubPix(gray, corners, (11, 11), (-1, -1),
                                   criteria)
        imgpoints.append(corners2)

        # Draw and display the corners
        cv.drawChessboardCorners(img, chessboard_size, corners2, ret)
        cv.imshow('img', img)
        cv.waitKey(500)

# Perform calibration
ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(objpoints, imgpoints,
    gray.shape[::-1], None, None)
# Print out the calibration results
print("Calibration successful:", ret)
print("\nCamera Matrix:\n", mtx)
print("\nDistortion Coefficients:\n", dist)

# Transform the matrix and distortion coefficients to writable lists
data = {
    'camera_matrix': np.asarray(mtx).tolist(),
    'dist_coeff': np.asarray(dist).tolist()
}

# Save the calibration results to a file
with open("calibration_matrix.yaml", "w") as f:
    yaml.dump(data, f)

print("\nCalibration done. Results saved to calibration_matrix.yaml")


