# Tello ArUco Autonomous Navigation

Autonomous indoor navigation of a Ryze Tello quadcopter using **Python**, **OpenCV**, and **ArUco markers** for camera-based pose estimation without GPS.

## Project overview

This group project was developed for **ELVE3610 – Introduction to Robotics** at **OsloMet**, autumn 2025. The quadcopter uses its onboard camera to detect ArUco markers, estimate their relative pose, search the environment by rotating 360°, select the nearest marker, and navigate toward a target distance of 0.5 m before landing. A 3D visualization shows marker positions and orientations relative to the camera.

## Features

- Camera calibration using a chessboard pattern
- ArUco marker detection and relative pose estimation with OpenCV
- Camera-to-visualization coordinate transformations
- 360° marker search and nearest-marker selection
- Tello command and video communication over Wi-Fi / UDP
- 3D pose visualization using Matplotlib

## Files

| File | Purpose |
| --- | --- |
| `main.py` | Tello communication, live video, marker search, navigation, and landing |
| `ArUco_tagg.py` | ArUco detection and pose estimation |
| `pose_tools.py` | Pose reporting and coordinate transformations |
| `Visualize.py` | 3D visualization of marker poses |
| `kamera_kalibrering.py` | Camera calibration and YAML output |
| `requirements.txt` | Python package dependencies |

## Requirements

Python, a compatible Ryze Tello drone, and the packages in `requirements.txt`.

```bash
pip install -r requirements.txt
```

Connect your computer to the Tello Wi-Fi network, verify the local IP address and UDP setup in the scripts, and run the main program in an appropriate indoor test area.

> **Note:** These Python scripts were reconstructed from the code appendix of the original course report. PDF line wrapping and indentation were repaired, and the files pass Python syntax checks. They have **not** been retested with a physical drone as part of this repository preparation. The scripts retain some original project-specific assumptions, including hardcoded camera calibration parameters and local UDP network settings. Review these before flight.

## Results and limitations

In five reported full-procedure trials, the average measured landing distance from the selected marker was **508 mm**, compared with the **500 mm target**. The project also documented lateral positioning errors and drift due to air currents; precise landing was not consistently achieved. These are important limitations for future development.

## Team

Developed by **Vebjørn Lundal, Nanna Blichfeldt Knutson, Jarand Halbo Aspelund, Kristoffer Berget, and Fredrik Spydevold** (Group 15, OsloMet, 2025).

The repository presents the original group project and does not imply sole authorship.
